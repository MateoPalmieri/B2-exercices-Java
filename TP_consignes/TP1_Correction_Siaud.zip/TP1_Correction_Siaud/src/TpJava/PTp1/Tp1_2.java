/**
 * @author Cyprien Siaud
 * modification de @author D.Palermo
 */
package TpJava.PTp1;

import TpJava.PUtils.coms;

/** Exercice de calcul de l'aire d'un trapeze*/
public class Tp1_2 {
    /** Fonction principale*/
    public static void exo()
    {
        do {
            System.out.println("Calcul de l'aire d'un trapèze :\n");
            System.out.print("Longueur du côté inférieur (en m) : ");
            double a = coms.getReal();  // Récupération d'un réél
            System.out.print("Longueur du côté supérieur (en m) : ");
            double b = coms.getReal(); // Récupération d'un réél
            System.out.print("Hauteur du trapèze (en m) : ");
            double c = coms.getReal(); // Récupération d'un réél
            double result = (a + b) * c * 0.5; // Calcul de l'aire du trapèze

            System.out.println("Le trapèze a une aire de " + result + "m²");

        }
        while (coms.Restart());
    }
}
