/**
 * @author Cyprien Siaud
 * modification de @author D.Palermo
 */
package TpJava.PTp1;

import TpJava.PUtils.coms;

/** Exercice de conversion Binaire / Decimal*/
public class Tp1_3 {
    /** Fonction principale */
    public static void exo()
    {
        do {
            System.out.print("Voulez-vous convertir :\n     1-De Décimal en Binaire\n     2-De Binaire en Décimal\n? ");

            int choix = coms.getInt();
            while (choix < 1 || 2 < choix) { // On s'assure que le choix et possible
                System.out.print("Ce choix n'existe pas : ");
                choix = coms.getInt();
            }
            switch (choix) {
                case 1 -> { // De Décimal vers Binaire
                    System.out.print("Un entier : ");
                    int dec = coms.getInt(); // Récupération de la valeur Décimale
                    System.out.println(dec + " vaut " + decToBin(dec) + " en notation Binaire");
                    System.out.print(dec + " vaut " + Integer.toBinaryString(dec) + " en notation Binaire");
                }
                case 2 -> { // De Binaire vers Décimal
                    System.out.print("Un nombre binaire : ");
                    String bin = coms.getString(); // Récupération de la valeur Binaire
                    System.out.println(bin + " vaut " + binToDec(bin) + " en notation Décimale");
                    System.out.print(bin + " vaut " + Integer.parseInt(bin, 2) + " en notation Décimale");
                }
            }

        }
        while (coms.Restart());
    }

    /**@deprecated Fonction de conversion Décimal vers Binaire
     * @param nb Le nombre a convertir
     * @return Une suite e 1 et de 0 sous forme de String*/
    static String decToBin(Integer nb) // Fontion pour la conversion de Décimal vers Binaire
    {
        StringBuilder result = new StringBuilder();

        int[] binaire = new int[50];
        int index = 0;
        while(nb > 0){ // On "parcours" le nombre décimal
            binaire[index++] = nb%2; // utilisation du modulo pour déterminer les 0 et les 1
            nb = nb/2;
        }
        for(int i = index-1;i >= 0;i--){
            result.append(binaire[i]); // Conversion du tableau de 1 et de 0 en string
        }

        return result.toString();
    }
    /**@deprecated Fonction de conversion Décimal vers Binaire
     * @param nb La suite de 1 et de 0 a convertir
     * @return Un nombre entier*/
    static int binToDec(String nb) // Fontion pour la conversion de Binaire vers Décimal
    {
        int result = 0;
        int val = 1;

        for(int i=nb.length()-1; i>=0; i--){
            char letter = (nb.charAt(i));
            if(letter=='1'){ // Si c'est un 1 */
                result += val; // On ajoute la valeur
            }
            val *= 2; // On double la valeur pour avoir 1,2,4,8,16...
        }

        return result;
    }
}
