/**
 * @author Cyprien Siaud
 * modification de @author D.Palermo
 */
package TpJava.PTp1;
import TpJava.PUtils.coms;

import java.util.Random;

/** Exercice jeu du nombre mystere*/
public class Tp1_4 {
    /** Fonction principale*/
    public static void exo()
    {
        do {
            System.out.print("Le jeu du nombre mystère :\nNombre minimum : ");
            int min = coms.getInt(); // Récupération valeur minimale
            System.out.print("Nombre maximum : ");
            int max = coms.getInt(); // Récupération valeur maximale
            if (min > max) { // Vérification de valeur entre min et max
                int temp = min;
                min = max;
                max = temp;
            }

            Random r = new Random();
            int nb = r.nextInt((max - min) + 1) + min; // Définition d'un nombre aléatoire
            System.out.print("A votre avis ? "); // Premier essai
            int input = coms.getInt();
            int nbEssais = 1;

            while (input != nb) { // Tant que l'on a pas le bon nombre
                String val = input > nb ? "grand" : "petit";
                System.out.print(input + " est trop " + val + " : ");
                input = coms.getInt(); // On réessaye
                nbEssais++;
            }
            System.out.print("\nBravo vous avez trouvé au bout de " + nbEssais + " tentatives :)");
        }
        while (coms.Restart() );

    }
}