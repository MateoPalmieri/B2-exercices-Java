// @Name Saisie & Boucles

package TpJava.PTp1;

import TpJava.PUtils.coms;

/** Exercice de Saisie et de boucles*/
public class Tp1_1 {
    /** Fonction principale*/
    public static void exo()
    {
        do {
            System.out.print("Votre nom ? ");
            String name = coms.getString();
            System.out.println("Bonjour " + name);

            System.out.print("Un premier réél : ");
            double nb1 = coms.getReal();
            System.out.print("Un second réél : ");
            double nb2 = coms.getReal();
            System.out.println("     Le max des deux est : " + Math.max(nb1, nb2));

            System.out.print("Un entier ? ");
            int nb3 = coms.getInt();
            String res = nb3 % 2 == 0 ? "pair" : "impair";
            System.out.print("     " + nb3 + " est un nombre " + res);

        }
        while (coms.Restart());
    }
}