package TpJava;

/**
 * @author Cyprien Siaud
 * modification de @author D.Palermo
 */
import TpJava.PUtils.coms;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/** class Main du projet */
public class Main {

    /** Le menu
     * @param args null
     * @throws java.lang.ClassNotFoundException Pour la recuperation des classes par leur nom
     * @throws java.lang.InstantiationException Pour l'utilisation de newInstance()
     * @throws java.lang.IllegalAccessException Pour la methode invoke()
     * @throws java.lang.NoSuchMethodException Quand la methode demandee n'est pas trouvee
     * @throws java.lang.reflect.InvocationTargetException Quand la methode invoquee (par invoke()) pose probleme */
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        String [] names = { "Tp1_1","Tp1_2","Tp1_3","Tp1_4"};
        do {
            System.out.println("Quel exercice souhaitez-vous tester ?\n");
            for (int i = 0; i < names.length; i++) { // Affichage des choix possibles
                System.out.println((i + 1) + " - " + names[i]);
            }
            System.out.print("=> ");
            int choix = coms.getInt(); // Choix Utilisateur

            while (choix < 1 || names.length < choix) { // On s'assure que le choix et possible
                System.out.print("Ce choix n'existe pas : ");
                choix = coms.getInt();
            }

            String className = "TpJava.PTp1." + names[choix - 1]; // Classe à utiliser
            String methodName = "exo"; // Méthode à utiliser

            Class<?> clazz = Class.forName(className); // Création d'une nouvelle classe qui correspond à celle que l'on veut utiliser
            Object o = clazz.getDeclaredConstructor().newInstance(); // Copie de la classe par le Constructeur
            Method Exo = clazz.getMethod(methodName); // Récupération de la méthode dont on a besoins
            Exo.invoke(o); // Appel de la méthode

        } while( coms.Restart("Essayer un autre Exercice"));
    }
}
