/**
 * @author Cyprien Siaud
 * modification de @author D.Palermo
 */
package TpJava.PUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/** Methodes communes au projet */
public class coms {
    /** Verification du type double
     * @param str La valeur a verifier
     * @return  Un booleen */

    private static Scanner sc= new Scanner(System.in);

    public static boolean checkDouble(String str){
        try {  //Test de la conversion de la string en double
            Double.parseDouble(str);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;

    }
    /** Verification du type int
     * @param str La valeur a verifier
     * @return  Un booleen */
    public static boolean checkInt(String str){
        try {  //Test de la conversion de la string en Integer
            Integer.parseInt(str);
        } catch (NumberFormatException nfe) {
            return false;
        }
        return true;
    }

    /** Recuperation d'une valeur de type double
     * @return Un double */
    public static double getReal(){
        //Scanner sc= new Scanner(System.in);
        String temp= sc.nextLine();  // Récupération de la valeur dans une variable string

        while(!coms.checkDouble(temp)){
            if(temp.contains(",")){
                List<String> strList = Arrays.asList(temp.split(","));
                temp = String.join(".", strList);
            }else{
                System.out.print("Loupé, il faut un réél : ");
                temp = sc.nextLine();
            }
        }
        return Double.parseDouble(temp);
    }
    /** Recuperation d'une valeur de type int
     * @return Un int */
    public static int getInt(){
        //Scanner sc= new Scanner(System.in);
        String temp= sc.nextLine();

        while(!coms.checkInt(temp)){
            System.out.print("Loupé, il faut un entier : ");
            temp=sc.nextLine();
        }
        return Integer.parseInt(temp);
    }
    /** Recuperation d'une valeur de type String
     * @return Un String */
    public static String getString(){
        // Scanner sc= new Scanner(System.in);
        return sc.nextLine();
    }

    /** Demande de recommencement
     * @return Un booleen */
    public static boolean Restart(){
        //Scanner sc= new Scanner(System.in);
        System.out.print("\n\nVoulez-vous recommencer [oO] [nN] ? ");
        String temp = sc.nextLine();

        while(!temp.equals("o")&&!temp.equals("O")&&!temp.equals("n")&&!temp.equals("N")){ //Boucle en cas de caractère invalide
            System.out.print("Merci de répondre o,O,n ou N : ");
            temp = sc.nextLine();
        }

        return temp.equals("o") || temp.equals("O");// Si la réponse est positive
    }
    /** Demande de recommencement avec texte perso
     * @param str Le texte perso a utiliser
     * @return Un booleen */
    public static boolean Restart(String str){
       //Scanner sc= new Scanner(System.in);
        System.out.print(str + " [oO] [nN] ? ");
        String temp = sc.nextLine();

        while(!temp.equals("o")&&!temp.equals("O")&&!temp.equals("n")&&!temp.equals("N")){ //Boucle en cas de caractère invalid
            System.out.print("Merci de répondre o,O,n ou N : ");
            temp = sc.nextLine();
        }

        return temp.equals("o") || temp.equals("O");// Si la réponse est positive
    }



}