package TP2.PMenu;

import java.lang.reflect.InvocationTargetException;

public interface IMenu {
    void menu();
    static IMenu CreateMenu(String name) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        return (IMenu)Class.forName(name).getDeclaredConstructor().newInstance();

    }
}
