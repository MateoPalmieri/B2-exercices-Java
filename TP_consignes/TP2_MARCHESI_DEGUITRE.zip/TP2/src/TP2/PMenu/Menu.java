/** @author Louis Deguitre
 * @author Maxime Marchesi*/

package TP2.PMenu;

import java.lang.reflect.InvocationTargetException;
import java.util.Scanner;

import TP2.PEx.IExercice;
import TP2.PUtils.funcs;


class Menu implements IMenu{

        // Menu qui permet d'accéder à tous les exercices
        public void menu()  {

            String answer = "";

            while (!answer.equals("q")) {

                System.out.println();
                System.out.println("" +
                        "███╗   ███╗███████╗███╗   ██╗██╗   ██╗\n" +
                        "████╗ ████║██╔════╝████╗  ██║██║   ██║\n" +
                        "██╔████╔██║█████╗  ██╔██╗ ██║██║   ██║\n" +
                        "██║╚██╔╝██║██╔══╝  ██║╚██╗██║██║   ██║\n" +
                        "██║ ╚═╝ ██║███████╗██║ ╚████║╚██████╔╝\n" +
                        "╚═╝     ╚═╝╚══════╝╚═╝  ╚═══╝ ╚═════╝");

                System.out.println();
                System.out.println("1- Résoudre équation second degree");
                System.out.println("2- Programmer une suite");
                System.out.println("3- Suite de Fibonacci");
                System.out.println("4- Le nombre d'or & fibonnaci");
                System.out.println("5- Suite de Syracuse");
                System.out.println("6- Jeu des allumettes");
                System.out.println("Taper [q] pour quitter");
                System.out.print("\nRentrer votre choix : ");
                Scanner sc = new Scanner(System.in);
                answer = funcs.sc.nextLine();
                try {
                    switch (answer) {
                        case "1" -> IExercice.CreateExercice("TP2.PEx.Ex1").lancer();
                        case "2" -> IExercice.CreateExercice("TP2.PEx.Ex2").lancer();
                        case "3" -> IExercice.CreateExercice("TP2.PEx.Ex3").lancer();
                        case "4" -> IExercice.CreateExercice("TP2.PEx.Ex4").lancer();
                        case "5" -> IExercice.CreateExercice("TP2.PEx.Ex5").lancer();
                        case "6" -> IExercice.CreateExercice("TP2.PEx.Ex6").lancer();
                        case "q" -> {
                            break;
                        }
                        default -> {
                            System.out.println("Veuillez rentrer un choix valide\n");
                        }
                    }
                } catch (ClassNotFoundException | NoSuchMethodException e) {
                    e.printStackTrace();
                 } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                }
            }


            System.out.println("\nA la revoyure !");
            System.out.println("Fermeture ...");

            System.out.print("                                            ████    ██                                  \n" +
                    "                                              ████████  ████                            \n" +
                    "░░      ░░      ░░  ░░░░  ░░  ░░░░░░  ░░  ░░░░  ██████████      ░░░░      ░░      ░░  ░░\n" +
                    "                                            ████████████                                \n" +
                    "                                              ██████████                                \n" +
                    "                                            ██████████████                              \n" +
                    "                                          ████████  ██████                              \n" +
                    "                                          ██  ████    ████████                          \n" +
                    "                                          ██  ██      ██████                            \n" +
                    "                                        ████  ██        ████                            \n" +
                    "                                        ██    ██          ██                            \n" +
                    "                                        ██  ██████        ████                          \n" +
                    "                                      ████  ██████        ██████                        \n" +
                    "                                      ████    ██          ██████████                    \n" +
                    "                                    ██████    ██        ████░░░░░░░░██                  \n" +
                    "                                  ██░░░░██    ██        ██░░░░░░░░░░██                  \n" +
                    "                                ██░░░░░░░░████░░██    ██░░████████░░██                  \n" +
                    "                              ██░░██████░░░░░░░░░░████░░░░░░██░░░░░░██                  \n" +
                    "                              ██░░░░██░░░░░░██░░██░░░░░░░░██░░░░░░██                    \n" +
                    "                                ████░░░░░░░░░░░░░░░░░░░░░░██░░████                      \n" +
                    "                          ██████████░░░░░░░░░░░░░░░░░░░░░░████                          \n" +
                    "                      ████░░░░░░░░░░██████░░░░░░░░░░░░░░░░██                            \n" +
                    "                    ██░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░██                              \n" +
                    "                      ██████████████████░░░░░░░░░░░░░░░░██                              \n" +
                    "                              ██░░████████████░░░░░░░░██                                \n" +
                    "                                ██░░░░░░░░░░░░██████████                                \n" +
                    "                                  ████████████  ████████                                \n" +
                    "                                                ██    ██                                \n" +
                    "  ░░░░░░  ░░░░  ░░░░░░  ░░░░░░  ░░░░  ░░░░░░  ░░██    ██░░░░░░░░░░  ░░░░░░  ░░░░  ░░░░░░\n");
            return;
        }
    }



