/**
 * @author Louis Deguitre
 * @author Maxime Marchesi */

package TP2.PEx;

import TP2.PUtils.funcs;

 class Ex4 implements IExercice {

    @Override
    public void lancer() {

        // Affiche le titre
        funcs.displayTitle("" +
                "███╗   ██╗ ██████╗ ███╗   ███╗██████╗ ██████╗ ███████╗    ██████╗  ██████╗ ██████╗        ██╗       ███████╗██╗██████╗  ██████╗ ███╗   ██╗ █████╗  ██████╗ ██████╗██╗\n" +
                "████╗  ██║██╔═══██╗████╗ ████║██╔══██╗██╔══██╗██╔════╝    ██╔══██╗██╔═══██╗██╔══██╗       ██║       ██╔════╝██║██╔══██╗██╔═══██╗████╗  ██║██╔══██╗██╔════╝██╔════╝██║\n" +
                "██╔██╗ ██║██║   ██║██╔████╔██║██████╔╝██████╔╝█████╗      ██║  ██║██║   ██║██████╔╝    ████████╗    █████╗  ██║██████╔╝██║   ██║██╔██╗ ██║███████║██║     ██║     ██║\n" +
                "██║╚██╗██║██║   ██║██║╚██╔╝██║██╔══██╗██╔══██╗██╔══╝      ██║  ██║██║   ██║██╔══██╗    ██╔═██╔═╝    ██╔══╝  ██║██╔══██╗██║   ██║██║╚██╗██║██╔══██║██║     ██║     ██║\n" +
                "██║ ╚████║╚██████╔╝██║ ╚═╝ ██║██████╔╝██║  ██║███████╗    ██████╔╝╚██████╔╝██║  ██║    ██████║      ██║     ██║██████╔╝╚██████╔╝██║ ╚████║██║  ██║╚██████╗╚██████╗██║\n" +
                "╚═╝  ╚═══╝ ╚═════╝ ╚═╝     ╚═╝╚═════╝ ╚═╝  ╚═╝╚══════╝    ╚═════╝  ╚═════╝ ╚═╝  ╚═╝    ╚═════╝      ╚═╝     ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝╚═╝");

        do {
            int count = funcs.tryInt("\nRentrer le nombre de terme: ");
            System.out.println();
            // Affiche la suite jusqu'à count
            for (int i = 1; i <= count; ++i)
                System.out.println("O[" + Integer.toString(i) + "] = " + Double.toString(O(i)));

            // Variable qui contient le résutlat de la forumule qui calcule le nombre d'or
            double nbOr = (1 + Math.sqrt(5.0)) / 2;
            System.out.println("\nNombre d'Or = " + Double.toString(nbOr) + "\n");

        }while(funcs.restart("Voulez-vous effectuer un autre calcul ?"));

    }


    /** Fonction qui calcul la suite de O[n]
     * @param n Réel à calculer dans la suite
     * @return un double */
    private  double O(double n) {

        if(n == 1) return 1;
        return funcs.doubleF(n + 1)/funcs.doubleF(n);

    }
}
