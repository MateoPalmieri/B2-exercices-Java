/** @author Louis Deguitre
 * @author Maxime Marchesi*/

package TP2.PEx;

import java.util.Random;

import TP2.PUtils.funcs;

 class Ex6 implements IExercice {

    @Override
    public void lancer() {
        boolean restart= true;
       do {
        // Affiche le titre une seule fois
        if(displayTitle)
            funcs.displayTitle(" " +
                    "    ██╗███████╗██╗   ██╗    ██████╗ ███████╗███████╗     █████╗ ██╗     ██╗     ██╗   ██╗███╗   ███╗███████╗████████╗████████╗███████╗███████╗\n" +
                    "     ██║██╔════╝██║   ██║    ██╔══██╗██╔════╝██╔════╝    ██╔══██╗██║     ██║     ██║   ██║████╗ ████║██╔════╝╚══██╔══╝╚══██╔══╝██╔════╝██╔════╝\n" +
                    "     ██║█████╗  ██║   ██║    ██║  ██║█████╗  ███████╗    ███████║██║     ██║     ██║   ██║██╔████╔██║█████╗     ██║      ██║   █████╗  ███████╗\n" +
                    "██   ██║██╔══╝  ██║   ██║    ██║  ██║██╔══╝  ╚════██║    ██╔══██║██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝     ██║      ██║   ██╔══╝  ╚════██║\n" +
                    "╚█████╔╝███████╗╚██████╔╝    ██████╔╝███████╗███████║    ██║  ██║███████╗███████╗╚██████╔╝██║ ╚═╝ ██║███████╗   ██║      ██║   ███████╗███████║\n" +
                    " ╚════╝ ╚══════╝ ╚═════╝     ╚═════╝ ╚══════╝╚══════╝    ╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝   ╚═╝      ╚═╝   ╚══════╝╚══════╝");

        // Affiche le nombre de victoires de L'IA et du Joueur à partir de la 2e partie s'il rejoue
        if(this.IAVictory > 0 || this.HumanVictory > 0)
            System.out.print("\nVictoire IA: " + Integer.toString(this.IAVictory) +
                    "\nVictoire " + this.name + ": " + Integer.toString(this.HumanVictory));

        int startMatches = 0;
        String matches = "";
        boolean isTrue = true;

        System.out.println();

        // Si le joueur rejoue avec le même joueur il ne devra pas rentrer son nom à nouveau
        if(this.name == "") this.name = funcs.tryString("Rentrer votre nom: ");

        // Verification de l'input du joueur
        while(isTrue) {

            System.out.println();
            startMatches = funcs.tryInt("Choisir le nombre d'allumette de départ: ");

            // Le joueur ne peut jouer qu'avec un nombre d'allumettes compris entre 10 et 30
            if (startMatches < 10 || startMatches > 30) System.out.println("Veuillez rentrer un nombre d'allumette de départ compris entre 10 et 30");
            else isTrue = false;


        }

        // Remplie la string du nombre d'allumettes entrer par le joueur */
        for(int i = 0; i < startMatches; ++i) matches += "|";

        // Definie un chiffre aléatoire entre 1 et 2 afin de définir aléatoirement qui commence
        Random r = new Random();
        int randomStart = r.nextInt(3 - 1) + 1;

        // Si le nombre aleatoire est 1, c'est l'IA qui commence
        if (randomStart == 1) System.out.println("L'IA commence\n");
        else System.out.println(name + " commence\n");

        // Variable qui contiendra le nombre d'allumettes à enlever à la string qui contient toutes les allumettes
        int lessMatches = 0;


        while(matches.length() != 0) {

            // Affiche le nombre d'allumettes restante
            System.out.print("Allumettes restante = " + matches.length() + "  ");
            if(matches.length() < 10) System.out.print(" ");

            // Ajoute des espaces à la place des allumettes supprimées pour des raisons d'esthetique
            if (matches.length() < startMatches) {
                for (int i = matches.length(); i < startMatches; ++i) {
                    System.out.print(" ");
                }
            }

            System.out.print(matches + " ");

            if (randomStart == 1) {
                lessMatches = IA(matches.length());
                System.out.println("IA enlève: "+ Integer.toString(IA(matches.length())));
            }
            else lessMatches = funcs.tryInt(name + " enlève: ");

            // Renvoie un message d'erreur si vous essayer d'enlever plus de 3 allumettes ou 0 allumette
            if (lessMatches > 3 || lessMatches == 0) {

                System.out.println("\nVous pouvez enlever 1 à 3 allumette(s)\n");
                continue;
            }

            // Renvoie un message d'erreur si vous essayez d'enlever plus d'allumette qu'il en reste
            if (lessMatches > matches.length()) {

                System.out.println("\nIl reste " + matches.length() + " allumette(s) vous ne pouvez pas en enlever " + Integer.toString(lessMatches) + "\n");
                continue;
            }

            // Supprime le nombre d'allumettes choisies par le joueur à partir de l'index 0 dans la string qui contient les allumettes
            matches = matches.substring(lessMatches);

            // Permet de changer de joueur à chaque tour
            if (randomStart == 1) randomStart = 2;
            else randomStart = 1;

        }

        // Affiche le gagnant de la partie le dernier joueur à jouer à perdu
        if (randomStart == 1){
            // Ajoute une victoire à l'IA
            this.IAVictory += 1;
            System.out.println("\nIA à gagné !");
            System.out.println(name + " a perdu :(\n");
        }else {
            // Ajoute une victoire à l'humain
            this.HumanVictory += 1;
            System.out.println("\n" + name + " à gagné !");
            System.out.println("IA a perdu :)\n");
        }

        // Demande au joueur s'il veut rejouer
        restart = funcs.restart("Voulez-vous rejouer ?");

        if (restart) {
            boolean answer = funcs.restart("Avec le même joueur ?");
            if ( ! answer)
                // Sinon on ne garde rien afin de jouer avec un autre nom
                this.name="";
                this.HumanVictory = 0;
                this.IAVictory = 0;
            }
            displayTitle = false;
        } while (restart);
        }




        /** IA presque imbattable au jeu des allumettes
         * @param matchesLeft Le nombre d'allumettes restantes
         * @return un int, le nombre d'allumettes à enlever */
        private int IA(int matchesLeft) {

            // Si un joueur tombe sur 5 allumettes il a perdu
            // L'IA fera en sorte que ça tombe sur vous

            int lessMatches = 0;

            if (matchesLeft == 1) return 1;

            if(matchesLeft % 4 == 0) lessMatches = 3;
            else if(matchesLeft % 4 == 1) lessMatches = 2;
            else if(matchesLeft % 4 == 3) lessMatches = 2;
            else if (matchesLeft % 4 == 2) lessMatches = 1;

            return lessMatches;
        }

        // Sauvegarde le nombre de victoires de l'IA de l'utilisateur et le nom de l'utilisateur s'il décide de rejouer
        private  int IAVictory = 0;
        private  int HumanVictory = 0;
        private  String name = "";
        private  boolean displayTitle = true;

    }
