/** @author Louis Deguitre
 * @author Maxime Marchesi */

package TP2.PEx;

import TP2.PUtils.funcs;

 class Ex5 implements IExercice {

@Override
public void lancer() {

        // Affiche le titre
        funcs.displayTitle("" +
                "███████╗██╗   ██╗██╗████████╗███████╗    ██████╗ ███████╗    ███████╗██╗   ██╗██████╗  █████╗  ██████╗██╗   ██╗███████╗███████╗\n" +
                "██╔════╝██║   ██║██║╚══██╔══╝██╔════╝    ██╔══██╗██╔════╝    ██╔════╝╚██╗ ██╔╝██╔══██╗██╔══██╗██╔════╝██║   ██║██╔════╝██╔════╝\n" +
                "███████╗██║   ██║██║   ██║   █████╗      ██║  ██║█████╗      ███████╗ ╚████╔╝ ██████╔╝███████║██║     ██║   ██║███████╗█████╗  \n" +
                "╚════██║██║   ██║██║   ██║   ██╔══╝      ██║  ██║██╔══╝      ╚════██║  ╚██╔╝  ██╔══██╗██╔══██║██║     ██║   ██║╚════██║██╔══╝  \n" +
                "███████║╚██████╔╝██║   ██║   ███████╗    ██████╔╝███████╗    ███████║   ██║   ██║  ██║██║  ██║╚██████╗╚██████╔╝███████║███████╗\n" +
                "╚══════╝ ╚═════╝ ╚═╝   ╚═╝   ╚══════╝    ╚═════╝ ╚══════╝    ╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚══════╝╚══════╝");

        do {
            System.out.println();
            boolean isTrue = true;
            int nb = 0;

            // Invite l'utilisateur à rentrer un entier positif sinon un message d'erreur s'affiche
            while (isTrue) {
                nb = funcs.tryInt("Rentrer un entier: ");
                if (nb < 0) System.out.println("Veuillez rentrer un entier positif");
                else isTrue = false;
            }

            System.out.print("\nSuite de Syracuse de " + Integer.toString(nb) + " = ");

            while (nb != 1) {

                System.out.print(Integer.toString(nb) + " ");

                // Algo qui calcule la suite de syracuse
                if (nb % 2 == 0) nb /= 2;
                else {
                    nb = 3*nb+1;
                }
            }
            // Affiche 1 le dernier entier de la suite
            System.out.print("1\n\n");

        }while(funcs.restart("Voulez-vous effectuer un autre calcul ?"));

    }
}
