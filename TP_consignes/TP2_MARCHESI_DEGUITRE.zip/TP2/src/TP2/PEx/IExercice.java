package TP2.PEx;

import java.lang.reflect.InvocationTargetException;

public interface IExercice {
    void lancer();
    static IExercice CreateExercice(String name) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        return (IExercice)Class.forName(name).getDeclaredConstructor().newInstance();

    }
}
