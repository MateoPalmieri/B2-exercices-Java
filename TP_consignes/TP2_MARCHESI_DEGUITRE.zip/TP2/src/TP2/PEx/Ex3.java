/**
 * @author Louis Deguitre
 * @author Maxime Marchesi*/

package TP2.PEx;

import TP2.PUtils.funcs;

public class Ex3 implements IExercice {

    @Override
    public void lancer() {

        // Affiche le titre
        funcs.displayTitle("""
                ███████╗██╗   ██╗██╗████████╗███████╗    ██████╗ ███████╗    ███████╗██╗██████╗  ██████╗ ███╗   ██╗ █████╗  ██████╗ ██████╗██╗
                ██╔════╝██║   ██║██║╚══██╔══╝██╔════╝    ██╔══██╗██╔════╝    ██╔════╝██║██╔══██╗██╔═══██╗████╗  ██║██╔══██╗██╔════╝██╔════╝██║
                ███████╗██║   ██║██║   ██║   █████╗      ██║  ██║█████╗      █████╗  ██║██████╔╝██║   ██║██╔██╗ ██║███████║██║     ██║     ██║
                ╚════██║██║   ██║██║   ██║   ██╔══╝      ██║  ██║██╔══╝      ██╔══╝  ██║██╔══██╗██║   ██║██║╚██╗██║██╔══██║██║     ██║     ██║
                ███████║╚██████╔╝██║   ██║   ███████╗    ██████╔╝███████╗    ██║     ██║██████╔╝╚██████╔╝██║ ╚████║██║  ██║╚██████╗╚██████╗██║
                ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   ╚══════╝    ╚═════╝ ╚══════╝    ╚═╝     ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝╚═╝""");

        do {
            System.out.println();
            boolean isTrue = true;
            long count = 0;

            // Invite l'utilisateur de rentrer le nombre de termes à calculer dans la suite de fibonacci
            while(isTrue) {

                count = funcs.tryLong("Rentrer le nombre de terme: ");

                // Par soucis de lisiblité j'ai fixé la limite entre -30 et 30
                if (count > 30 || count < -30) System.out.println("Veuillez rentrer un entier compris entre -30 et 30\n");
                else isTrue = false;
            }

            int i = 0;

            System.out.println();
            System.out.print("La suite jusqu'à F(" + count + ") = " );

            // Affiche la suite positive
            if (count > 0) {

                for(i = 0; i <= count; ++i)  System.out.print(funcs.F(i) + " ");

                System.out.println();
                System.out.println("Résultat de F(" + count + ") = " + funcs.F(count));

                // Affiche la suite négative
            } else if (count < 0) {

                count *= -1;
                while(i <= count) {

                    if(i % 2 == 0)

                        if (i == 0) System.out.print("0 ");
                        else System.out.print(funcs.F(i) * -1+ " ");

                    else  System.out.print(funcs.F(i) + " ");
                    ++i;

                }

                System.out.println();

                // Affiche le résultat
                if(count % 2 == 0) System.out.println("Résultat de F(-" + count + ") = " + funcs.F(count) *-1);
                else System.out.println("Résultat de F(" + count + ") = " + funcs.F(count));

            }else {
                System.out.print("0");
            }

            System.out.println();

        }while(funcs.restart("Voulez-vous effectuer un autre calcul ?"));

    }
}
