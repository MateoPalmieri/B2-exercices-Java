/**
 * @author Louis Deguitre
 * @author Maxime Marchesi*/

package TP2.PEx;

import TP2.PUtils.funcs;

 class Ex2 implements IExercice {

    @Override
    public void lancer() {

        // Affiche le titre
        funcs.displayTitle("" +
            "██████╗ ██████╗  ██████╗  ██████╗ ██████╗  █████╗ ███╗   ███╗███╗   ███╗███████╗██████╗     ██╗   ██╗███╗   ██╗███████╗    ███████╗██╗   ██╗██╗████████╗███████╗\n" +
            "██╔══██╗██╔══██╗██╔═══██╗██╔════╝ ██╔══██╗██╔══██╗████╗ ████║████╗ ████║██╔════╝██╔══██╗    ██║   ██║████╗  ██║██╔════╝    ██╔════╝██║   ██║██║╚══██╔══╝██╔════╝\n" +
            "██████╔╝██████╔╝██║   ██║██║  ███╗██████╔╝███████║██╔████╔██║██╔████╔██║█████╗  ██████╔╝    ██║   ██║██╔██╗ ██║█████╗      ███████╗██║   ██║██║   ██║   █████╗  \n" +
            "██╔═══╝ ██╔══██╗██║   ██║██║   ██║██╔══██╗██╔══██║██║╚██╔╝██║██║╚██╔╝██║██╔══╝  ██╔══██╗    ██║   ██║██║╚██╗██║██╔══╝      ╚════██║██║   ██║██║   ██║   ██╔══╝  \n" +
            "██║     ██║  ██║╚██████╔╝╚██████╔╝██║  ██║██║  ██║██║ ╚═╝ ██║██║ ╚═╝ ██║███████╗██║  ██║    ╚██████╔╝██║ ╚████║███████╗    ███████║╚██████╔╝██║   ██║   ███████╗\n" +
            "╚═╝     ╚═╝  ╚═╝ ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝     ╚═════╝ ╚═╝  ╚═══╝╚══════╝    ╚══════╝ ╚═════╝ ╚═╝   ╚═╝   ╚══════╝");



        do {
            System.out.println();
            int x = 10;
            // racine carré
            double R1 = Math.sqrt(2.0);
            double calcul = 2 + R1;
            boolean isTrue = true;
            int n = 0;

            while(isTrue) {
                n = funcs.tryInt("Rentrer un entier: ");
                if (n > 262 || n < 0 || n == 0) System.out.println("Veuillez rentrer un entier compris entre 1 et 262\n");
                else isTrue = false;
            }


            for (int i = 1; i < n; ++i) {
                double Rn = Math.sqrt(calcul);

                if(i == 1) System.out.print("\nR1 = " + R1 + "\n");

                if (i == x) {
                    System.out.print("R" + i + " = " + Rn + "\n");
                    calcul = 2 + Rn;
                    x += 10;
                }
                if (i + 1 == n) {
                    System.out.print("R" + n + " = " + Rn + "\n");
                    calcul = 2 + Rn;
                }

            }
            // Suite réalisée grace a l'exercice 1 vous pouvez tester également
            System.out.print("\nCette suite tant vers le résultats positif de la résolution de\n");

            int[] codeRetour={-1};
            double[] res = Ex1.resolutionEquation( 1, -1 , -2, codeRetour);

            System.out.print("l'équation x^2-x-2 = 0 qui est x1=" +res[0]  + " et x2 =" + res[1] +" \n\n");

        }while(funcs.restart("Voulez-vous effectuer un autre calcul ?"));
    }
}