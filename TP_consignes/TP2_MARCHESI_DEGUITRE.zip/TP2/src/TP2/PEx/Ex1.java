/**
 * @author Louis Deguitre
 * @author Maxime Marchesi
 *
 * Modification
 * @autor D.Palermo
 */

package TP2.PEx;

import TP2.PUtils.funcs;

class Ex1 implements IExercice {

    @Override
    public void lancer() {

        // Affiche le titre
        funcs.displayTitle(" " +
                "█████╗ ██╗  ██╗    ██████╗     ██████╗ ██╗  ██╗    ██████╗      ██████╗     ██████╗ \n" +
                "██╔══██╗╚██╗██╔╝    ╚════██╗    ██╔══██╗╚██╗██╔╝    ╚════██╗    ██╔════╝    ██╔═████╗\n" +
                "███████║ ╚███╔╝      █████╔╝    ██████╔╝ ╚███╔╝      █████╔╝    ██║         ██║██╔██║\n" +
                "██╔══██║ ██╔██╗     ██╔═══╝     ██╔══██╗ ██╔██╗     ██╔═══╝     ██║         ████╔╝██║\n" +
                "██║  ██║██╔╝ ██╗    ███████╗    ██████╔╝██╔╝ ██╗    ███████╗    ╚██████╗    ╚██████╔╝\n" +
                "╚═╝  ╚═╝╚═╝  ╚═╝    ╚══════╝    ╚═════╝ ╚═╝  ╚═╝    ╚══════╝     ╚═════╝     ╚═════╝ \n" +
                "                                                                                     ");

        double n1 = 0;
        double n2 = 0;
        double n3 = 0;


        do {
            System.out.println();
            boolean isTrue = true;

            // On rentre les valeures A B et C
            while(isTrue){
                n1 = funcs.tryFloat("Rentrer un réel A: ");
                // si A = 0 diviser par 2A impossible
                if (n1 == 0){
                    System.out.print("A doit etre different de 0\n");
                }else{
                    isTrue = false;
                }

            }
            n2 = funcs.tryFloat("Rentrer un réel B: ");
            n3 = funcs.tryFloat("Rentrer un réel C: ");
            System.out.println("\n"+n1+"x^2 + "+ n2+"x + " + n3 + " = 0 :");
            int[] codeRetour={-1};
            double[] res = Ex1.resolutionEquation( n1, n2 , n3, codeRetour);

            switch ( codeRetour[0]) {
                case 0 -> System.out.println("Pas de solution reel  car le discriminant est négatif\n");
                case 1 -> System.out.println("le résultat de l'équation est "+res[0]+" avec discriminant = 0\n");
                case 2 -> System.out.println("le résultat de l'équation est x1="+res[0]+" et  x2="+res[1]+"\n");
            }

        }while(funcs.restart("Voulez-vous effectuer un autre calcul ?"));

    }


    public static double[] resolutionEquation(double n1,double n2 ,double n3,int[] codeRetour){
        double [] res=  {0,0};
        double D = n2*n2 - ( 4 * n1 * n3 );

        // Si discriminant négatif nombre complexe
        if (D < 0){
            codeRetour[0]=0;
        } else if (D == 0){
            res[0] = -n2 / (2. *n1 );
            res[1]=res[0];
            codeRetour[0]=1;
        } else {
            double ok = 2 * n1;
            double racine = Math.sqrt(D);
            double pp1 = -n2 - racine;
            double pp2 = -n2 + racine;
            res[0] = pp1 / ok;
            res[1] = pp2 / ok;
            codeRetour[0]=2;
         }

        return res;
    }

}
