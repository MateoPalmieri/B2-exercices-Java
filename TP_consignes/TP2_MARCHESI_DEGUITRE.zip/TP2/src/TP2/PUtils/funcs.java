/** @author Louis Deguitre
 * @author Maxime Marchesi */

package TP2.PUtils;

import java.util.Scanner;

public class funcs {

    // Scanner de l'input
    public static final Scanner sc = new Scanner(System.in);


    /** Fonction qui affiche le titre de chaque exercice
     * @param str Le titre personnalisé à afficher */
    public static void displayTitle(String str) {

       System.out.println("\n\n" + str );
    }

    /** Fonction qui demande à l'utilisateur de rentrer un entier valide
     * @param str Le texte personnalisé à afficher
     * @return un int */
    public static int tryInt(String str) {
        int nb = 0;
        boolean isTrue = true;

        while(isTrue) {
            System.out.print(str);
            try {
                String nbStr = funcs.sc.nextLine();
                nb =  Integer.parseInt(nbStr);
                isTrue = false;
                // Gère les erreurs de saisie
            } catch (NumberFormatException nfe) {
                System.out.println("Veuillez rentrer un entier valide\n");
            }
        }
        return nb;
    }

    /** Fonction qui demande à l'utilisateur de rentrer un entier valide
     * @param str Le texte personnalisé à afficher
     * @return un long */
    public static long tryLong(String str) {
        long nb = 0;
        boolean isTrue = true;

        while(isTrue) {
            System.out.print(str);
            try {
                String nbStr = funcs.sc.nextLine();
                nb =  Long.parseLong(nbStr);
                isTrue = false;
                // Gère les erreurs de saisie
            } catch (NumberFormatException nfe) {
                System.out.println("Veuillez rentrer un entier valide\n");
            }
        }
        return nb;
    }

    /** Fonction qui demande à l'utilisateur de rentrer un réel valide
     * @param str Le texte personnalisé à afficher
     * @return un double */
    public static double tryFloat(String str) {

        double nb = 0.0;
        boolean isTrue = true;

        while (isTrue) {
            System.out.print(str);
            try {
                String nbStr = funcs.sc.nextLine();
                nb = Double.parseDouble(nbStr);
                isTrue = false;
                // Gestion des erreurs de saisie
            } catch (Exception e) {
                System.out.println("Veuillez rentrer un réel valide (un réel avec virgule pas de point)\n");
            }
        }
        return nb;
    }


    /** Fonction qui demande à l'utilisateur de rentrer une string valide
     * @param str Le texte personnalisé à afficher
     * @return une string */
    public static String tryString(String str) {

        boolean isTrue = true;
        // Regex de toutes les lettres de l'alphabet
        String regex = "^[a-zA-Z]+$";
        String s = "";

        while (isTrue) {
            System.out.print(str);
            s = funcs.sc.nextLine();

            // Gestion des erreurs de saisie
            if(s.matches(regex)) isTrue = false;
            else System.out.println("Veuillez rentrer uniquement des lettres\n");

        }
        return s;
    }


    /**  Fonction qui propose à l'utilisateur de recommencer
     * @param str Le texte personnalisé à afficher
     * @return un boolean */
    public static boolean restart(String str) {

        boolean again = false;
        boolean isTrue = true;
        String answer;

        while(isTrue) {

            System.out.print(str + " [y/n]: ");
            answer = funcs.sc.nextLine();

            switch (answer) {
                case "y", "Y" -> {
                    again = true;
                    isTrue = false;
                }
                case "n", "N" -> {
                    isTrue = false;
                }
                //Gestion des erreurs de saisie
                default -> System.out.println("Veuillez rentrer un choix valide\n");
            }
        }
        return again;
    }

    /** Fonction qui calcul la suite de Fibonacci avec des int
     * @param count le nombre de termes pour la suite
     * @return un int */
    public static long F(long count) {

        long nb0 = 0;
        long nb1 = 1;
        long result = 0;

        if (count <= 1) return count;

        for(int i = 2; i<=count; ++i) {
            result = nb0 + nb1;
            nb0 = nb1;
            nb1 = result;
        }
        return result;
    }

    /** Fonction qui calcul la suite de Fibonnaci avec des doubles
     * @param count le nombre de termes pour la suite
     * @return un double */
    public static double doubleF(double count) {

        double nb0 = 0;
        double nb1 = 1;
        double result = 0;

        if (count <= 1) return count;

        for(int i = 2; i<=count; ++i) {
            result = nb0 + nb1;
            nb0 = nb1;
            nb1 = result;
        }
        return result;
    }
}
