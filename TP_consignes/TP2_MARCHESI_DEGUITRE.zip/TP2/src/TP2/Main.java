package TP2;
/**
 * @author Louis Deguitre
 * @author Maxime Marchesi
 *
 * Modification
 * @autor D.Palermo
 * */

import TP2.PMenu.IMenu;

import java.lang.reflect.InvocationTargetException;

/**
* la classe Main contient  le programme principal
*/
public class Main {

    public static void main(String[] args) throws ClassNotFoundException, InvocationTargetException, NoSuchMethodException, InstantiationException, IllegalAccessException {

        IMenu.CreateMenu("TP2.PMenu.Menu").menu();
    }

}
